Unzip everything into a folder.  Put this folder in "Documents" or somewhere out of the way.

Then right click on the .scr file and choose "Install".

Choose "Settings" and browse to the folder containing TTYREC files.  I included some samples in the zip.  You can download more from nethack.alt.org (though depending on settings or version, not everything will work!)

That should do it.  Let me know how it works out for you!

Adam
aspragg@yahoo.com